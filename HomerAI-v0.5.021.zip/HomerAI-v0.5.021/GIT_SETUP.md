# HomerAI — Git Commands for v0.5.021

```bash
cd /home/ozzy/ai/HomerAI/homerai_dev
```

```bash
git add -A
```

```bash
git commit -m "v0.5.021 — performance: batched NPC brains, brain throttle, smart summary, card resolution pre-check"
```

```bash
git push origin master
```

```bash
git tag -a v0.5.021 -m "v0.5.021 — 60-75% fewer inference calls per turn"
```

```bash
git push origin --tags
```
